package com.result.service;

import java.util.List;

import com.result.domain.StudentResult;
import com.result.domain.princeple;

public interface serviceInterface {
	
	public void insertStudent(StudentResult pri);
	
	public List<StudentResult> getAll();

	public String checkLogin(princeple pr);
	
	public void insertPrinceple(princeple pri);

}
