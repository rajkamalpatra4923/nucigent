package com.result.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.result.domain.StudentResult;
import com.result.domain.princeple;
import com.result.repository.princepleInterface;
import com.result.repository.studentInterface;

@Service
public class serviceImpl implements serviceInterface{
	@Autowired
	private princepleInterface princeple;
	
	@Autowired
	public studentInterface student;
	
	
	public void insertStudent(StudentResult stu) {
		
		int eng=stu.getEnglish();
		int math=stu.getMath();
		int sc=stu.getScience();
		int total=eng+math+sc;
		
		stu.setTotal(total);
		student.save(stu);
		
	}
	
	
	public void insertPrinceple(princeple pri) {
		princeple.save(pri);
	}
	
	public String checkLogin(princeple prince)
	{
		princeple checkLogin = princeple.getCheckLogin(prince.getGmail(),prince.getPassword());
		List<princeple> all = princeple.findAll();
		for(princeple one:all) {
			if (!one.getGmail().equalsIgnoreCase(prince.getGmail()) 
				    && !one.getPassword().equals(prince.getPassword())) {
				return null;
				}

		}
		
		
		
		
		
		if (prince.getGmail().equalsIgnoreCase(checkLogin.getGmail()) 
			    && prince.getPassword().equals(checkLogin.getPassword()))
		{
			return "Successfull";
		}
		else {
			return "password email incorrect";
		}
		
	}
	
	public List<StudentResult> getAll()
	{
		List<StudentResult> list = student.findAll();
		return list;
	}

}
