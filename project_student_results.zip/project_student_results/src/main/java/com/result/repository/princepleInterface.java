package com.result.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.result.domain.princeple;

public interface princepleInterface extends JpaRepository<princeple,Integer>{
	
	@Query("select e from princeple e where e.gmail=:gmail AND e.password=:password")
	public princeple getCheckLogin(@Param("gmail")String mail,@Param("password")Integer pass);

}
