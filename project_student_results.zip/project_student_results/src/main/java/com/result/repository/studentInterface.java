package com.result.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.result.domain.StudentResult;

public interface studentInterface extends JpaRepository<StudentResult,Integer> {

}
