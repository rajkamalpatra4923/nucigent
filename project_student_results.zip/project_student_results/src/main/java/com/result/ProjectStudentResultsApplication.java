package com.result;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectStudentResultsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectStudentResultsApplication.class, args);
	}

}
