package com.result.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.result.domain.StudentResult;
import com.result.domain.princeple;
import com.result.service.serviceInterface;


@Controller
public class mycontroller {
	@Autowired
	public serviceInterface service;
	
	
	@GetMapping("/")
	public String studentRegester(@ModelAttribute("key") StudentResult stu) {
		
		return "Login";
		
	}
	
	@PostMapping("/savestudent")
	public String insertStudent(@ModelAttribute("key") StudentResult stu) {
		service.insertStudent(stu);
		return "StudentRegester";
	}
	
	@GetMapping("/AddAdmin")
	public String newAdmin(@ModelAttribute("key1") princeple pri) {
		return "RegesterAdmin";
	}
	
	
	@PostMapping("/savePrincepleData")
	public String savePrinceple(@ModelAttribute("key1") princeple pri) {
		service.insertPrinceple(pri);
		return "RegesterAdmin";
	}
	
	@GetMapping("/StudentRegester")
	public void getMethodName() {

	}
	
	@GetMapping("/show")
	public String allResult(Model m) {
		List<StudentResult> ls = service.getAll();
		m.addAttribute("result", ls);
		return "AllData";
	}
	
	@PostMapping("/checkLogin")
	public String check(@ModelAttribute princeple pr,Model m){
		String checkLogin = service.checkLogin(pr);
		
		if(checkLogin==null)
		{
			m.addAttribute("message", "Record is not avilable in database");
			return "Login";
		}
		return "redirect:show";
	}
	
	

}
