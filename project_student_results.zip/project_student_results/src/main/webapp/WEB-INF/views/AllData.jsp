<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h3>STUDENT RESULTS</h3><br>
	<table border="1">
		<tr>
		    <th>ROLL_NO</th>
			<th>STUDENT_NAME</th>
			<th>MATH</th>
			<th>SCIENCE</th>
			<th>ENGLISH</th>
			<th>Total MArk</th>
		</tr>
		<tbody>
		<c:forEach var="data" items="${result}">
			<tr>
				<td>${data.rollnumber}</td>
				<td>${data.studentname}</td>
				<td>${data.math}</td>
				<td>${data.science}</td>
				<td>${data.english}</td>
				<td>${data.total }</td>
			</tr>
		</c:forEach>
		</tbody>
	</table>
	
	<a href="StudentRegester">Insert Student Mark</a><br><br>
<a href="/">GO TO LOG_IN PAGE</a>

<br>${message}
</body>
</html>