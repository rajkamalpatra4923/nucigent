<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<center>
<h3>REGESTER NEW ADMINISTATER</h3><br>

<form action="savePrincepleData" method="post" modelAttribute="key1">
enter new gmail <input type="text" name="gmail" placeholder="enter gmail"/><br>
enter new password <input type="text" name="password" placeholder="enter password"/><br>
<input type="submit" value="register"/>
</form>

<a href="/">GO TO lOG_IN PAGE</a>
</center>
</body>
</html>