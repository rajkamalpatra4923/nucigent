<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<center>
<h3>ADMINISTATER LOGIN PAGE</h3><br>

<form action="checkLogin" method="post" modelAttribute="key">
enter gmail id <input type="text" name="gmail" placeholder="enter gmail"/><br>
enter password <input type="text" name="password" placeholder="enter password"/><br>
<input type="submit" value="register"/>
</form>

<a href="AddAdmin">regester adminstater</a><br>
<br><br>${message }

</center>
</body>
</html>