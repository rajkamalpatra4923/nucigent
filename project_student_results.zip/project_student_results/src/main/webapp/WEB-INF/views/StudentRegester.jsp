<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<center>
<h3>ENTER STUDENT MARKS</h3><br>

<form action="savestudent" method="post" modelattribute="key">
<input type="text" name="studentname" placeholder="enter studentName"/><br><br>
<input type="text" name="math" placeholder="enter math mark"/><br><br>
<input type="text" name="science" placeholder="enter science mark"/><br><br>
<input type="text" name="english" placeholder="enter english mark"/><br><br>
<input type="submit" value="save"/><br>

<a href="show">show student record</a>
</form>

</center>

</body>
</html>