package com.result;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectStudentResultsApplicationTests {

	@Test
	void contextLoads() {
	}

}
